$(document).ready(() => {

      $("#Vow").click( () => {
        $("#VotD_span").delay(500).slideUp(800);
        $("#VotD_span").toggleClass("invis");
        });
     
       
});