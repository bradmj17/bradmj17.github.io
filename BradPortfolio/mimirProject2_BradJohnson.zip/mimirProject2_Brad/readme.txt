MIMIR, BRADLEY JOHNSON

-

-the mimir folder includes the prototype
-the forms folder contains the forms
-the document folder contains:
	-link to original youtube video
	-link to questionnaire
	-link to prototype
	-written proposal 
	-powerpoint

--

-i recorded a youtube video submission early in the week, where I explained examples very well.
	-it did not represent my forms well
	-my prototype at the time had a typo.
-since i could not record again this weekend, I have fixed my forms and all the issues from the recording.
-maybe watch the recording on 1.5x speed for me to explain the examples of usage
-i have included a written proposal that is confusing due to the content being confusing

---

TLDR: the youtube video does a good job contextualizing everything despite having old, outdated forms.
